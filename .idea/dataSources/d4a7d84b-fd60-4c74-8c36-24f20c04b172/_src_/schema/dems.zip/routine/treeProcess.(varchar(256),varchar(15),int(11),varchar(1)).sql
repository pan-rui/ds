CREATE FUNCTION treeProcess(tree VARCHAR(256), suffix VARCHAR(15), pos INT, dlim VARCHAR(1))
  RETURNS VARCHAR(256)
  BEGIN
    DECLARE id VARCHAR(32);
    DECLARE iTree VARCHAR(256) DEFAULT '';
    DECLARE i INT(2) DEFAULT 0;
#     SET id = LENGTH(tree);
    REPEAT SET i = i + 1;
      set id=SUBSTRING_INDEX(SUBSTRING_INDEX(tree, dlim, i), dlim, -1);
      set iTree=CONCAT(iTree,dlim,INSERT(id,pos,11,suffix));
    UNTIL LENGTH(tree) =LENGTH(iTree)-1 END REPEAT;
    RETURN SUBSTR(iTree,2);
END;
