CREATE PROCEDURE cleanData(IN schem VARCHAR(64))
  BEGIN
    DECLARE Done INT DEFAULT 0;
    DECLARE tbName VARCHAR(32);
    DECLARE rs CURSOR FOR SELECT table_name FROM information_schema.tables WHERE table_schema= schem;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET Done = 1;
    OPEN rs;
    /* 遍历数据表 */
    read_loop: LOOP
      FETCH next FROM rs INTO tbName;
      IF Done
      THEN
        LEAVE read_loop;
      END IF;
      IF tbName IS NOT NULL
      THEN
        set @stmt=CONCAT('TRUNCATE ',schem,'.',tbName);
        PREPARE s1 FROM @stmt;
        EXECUTE s1;
      END IF;
    END LOOP;
  END;
